
package org.snhu.cs320.appointment;

import org.snhu.cs320.exceptions.ValidationException;
import org.snhu.cs320.validation.Validation;

import java.util.Date;

public class Appointment {
    private final String appointmentId;
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) throws ValidationException {
        Validation.validateNotBlank(appointmentId, "appointmentId");
        Validation.validateLength(appointmentId, "appointmentId", 1, 10);
        Validation.validateNotBlank(description, "description");
        Validation.validateLength(description, "description", 1, 50);

        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new ValidationException("appointmentDate cannot be in the past or null");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate) throws ValidationException {
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new ValidationException("appointmentDate cannot be in the past or null");
        }
        this.appointmentDate = appointmentDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) throws ValidationException {
        Validation.validateNotBlank(description, "description");
        Validation.validateLength(description, "description", 1, 50);
        this.description = description;
    }
}
