
package org.snhu.cs320.appointment;

import org.snhu.cs320.exceptions.ValidationException;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    public static final Map<String, Appointment> APPOINTMENT_DATABASE = new HashMap<>();

    public static void add(Appointment appointment) throws ValidationException {
        if (APPOINTMENT_DATABASE.containsKey(appointment.getAppointmentId())) {
            throw new ValidationException("Duplicate ID");
        }
        APPOINTMENT_DATABASE.put(appointment.getAppointmentId(), appointment);
    }

    public static void delete(String appointmentId) {
        APPOINTMENT_DATABASE.remove(appointmentId);
    }
}
