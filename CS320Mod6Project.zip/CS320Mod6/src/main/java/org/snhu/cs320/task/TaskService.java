
package org.snhu.cs320.task;

import org.snhu.cs320.exceptions.ValidationException;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    public static final Map<String, Task> TASK_DATABASE = new HashMap<>();

    public static void add(Task task) throws ValidationException {
        if (TASK_DATABASE.containsKey(task.getTaskId())) {
            throw new ValidationException("Duplicate ID");
        }
        TASK_DATABASE.put(task.getTaskId(), task);
    }

    public static void delete(String taskId) {
        TASK_DATABASE.remove(taskId);
    }

    public static boolean update(String taskId, Task updatedTask) throws ValidationException {
        if (TASK_DATABASE.containsKey(taskId)) {
            TASK_DATABASE.put(taskId, updatedTask);
            return true;
        }
        return false;
    }
}
