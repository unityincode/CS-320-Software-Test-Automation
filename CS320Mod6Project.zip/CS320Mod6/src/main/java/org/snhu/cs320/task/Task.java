
package org.snhu.cs320.task;

import org.snhu.cs320.exceptions.ValidationException;
import org.snhu.cs320.validation.Validation;

public class Task {
    private final String taskId;
    private String name;
    private String description;

    public Task(String taskId, String name, String description) throws ValidationException {
        Validation.validateNotBlank(taskId, "taskId");
        Validation.validateLength(taskId, "taskId", 1, 10);
        Validation.validateNotBlank(name, "name");
        Validation.validateLength(name, "name", 1, 20);
        Validation.validateNotBlank(description, "description");
        Validation.validateLength(description, "description", 1, 50);

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) throws ValidationException {
        Validation.validateNotBlank(name, "name");
        Validation.validateLength(name, "name", 1, 20);
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) throws ValidationException {
        Validation.validateNotBlank(description, "description");
        Validation.validateLength(description, "description", 1, 50);
        this.description = description;
    }
}
