
package org.snhu.cs320.appointment;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.snhu.cs320.exceptions.ValidationException;

import java.util.Date;

class AppointmentServiceTest {

    @BeforeEach
    void init() {
        AppointmentService.APPOINTMENT_DATABASE.clear();
    }

    @Test
    void addSuccess() throws ValidationException {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("12345", futureDate, "Test appointment description.");
        AppointmentService.add(appointment);
        assertThat(AppointmentService.APPOINTMENT_DATABASE)
            .containsEntry("12345", appointment);
    }

    @Test
    void delete() throws ValidationException {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        AppointmentService.add(new Appointment("12345", futureDate, "Test appointment description."));
        AppointmentService.delete("12345");
        assertThat(AppointmentService.APPOINTMENT_DATABASE)
            .doesNotContainKey("12345");
    }
}
