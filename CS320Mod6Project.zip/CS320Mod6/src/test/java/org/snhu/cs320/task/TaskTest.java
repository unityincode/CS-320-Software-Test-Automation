
package org.snhu.cs320.task;

import org.junit.jupiter.api.Test;
import org.snhu.cs320.exceptions.ValidationException;

import static org.junit.jupiter.api.Assertions.*;

class TaskTest {

    // this test checks if a task is created successfully
    @Test
    void createTaskSuccess() throws ValidationException {
        Task task = new Task("12345", "Test Task", "This is a test task description.");
        assertEquals("12345", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a test task description.", task.getDescription());
    }

    // this test expects a failure when creating a task with invalid data
    @Test
    void createTaskFailure() {
        assertThrows(ValidationException.class, () -> {
            new Task("", "Test Task", "This is a test task description.");
        });
    }

    // this test checks for a null name, which should fail
    @Test
    void createTaskWithNullName() {
        assertThrows(ValidationException.class, () -> {
            new Task("12345", null, "This is a test task description.");
        });
    }

    // this test checks for an overly long description, which should fail
    @Test
    void createTaskWithLongDescription() {
        assertThrows(ValidationException.class, () -> {
            new Task("12345", "Test Task", "this description is way too long to be valid as it exceeds fifty characters.");
        });
    }
}
