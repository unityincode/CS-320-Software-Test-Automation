
package org.snhu.cs320.appointment;

import org.junit.jupiter.api.Test;
import org.snhu.cs320.exceptions.ValidationException;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class AppointmentTest {

    // this test checks if an appointment is created successfully
    @Test
    void createAppointmentSuccess() throws ValidationException {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("12345", futureDate, "Test appointment description.");
        assertEquals("12345", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Test appointment description.", appointment.getDescription());
    }

    // this test expects a failure when creating an appointment with invalid data
    @Test
    void createAppointmentFailure() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000);
        assertThrows(ValidationException.class, () -> {
            new Appointment("", pastDate, "Test appointment description.");
        });
    }

    // this test checks for a null appointment date, which should fail
    @Test
    void createAppointmentWithNullDate() {
        assertThrows(ValidationException.class, () -> {
            new Appointment("12345", null, "Test appointment description.");
        });
    }

    // this test checks for an appointment date in the past, which should fail
    @Test
    void createAppointmentWithPastDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000);
        assertThrows(ValidationException.class, () -> {
            new Appointment("12345", pastDate, "Test appointment description.");
        });
    }
}
