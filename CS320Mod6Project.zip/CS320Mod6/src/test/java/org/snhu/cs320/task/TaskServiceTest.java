
package org.snhu.cs320.task;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.snhu.cs320.exceptions.ValidationException;

class TaskServiceTest {

    @BeforeEach
    void init() {
        TaskService.TASK_DATABASE.clear();
    }

    @Test
    void addSuccess() throws ValidationException {
        Task task = new Task("12345", "Test Task", "This is a test task description.");
        TaskService.add(task);
        assertThat(TaskService.TASK_DATABASE)
            .containsEntry("12345", task);
    }

    @Test
    void delete() throws ValidationException {
        TaskService.add(new Task("12345", "Test Task", "This is a test task description."));
        TaskService.delete("12345");
        assertThat(TaskService.TASK_DATABASE)
            .doesNotContainKey("12345");
    }

    @Test
    void updateSuccess() throws ValidationException {
        TaskService.add(new Task("12345", "Test Task", "This is a test task description."));

        Task updated = new Task("12345", "Updated Task", "Updated description.");
        assertThat(TaskService.update("12345", updated)).isTrue();

        assertThat(TaskService.TASK_DATABASE)
            .extracting("12345")
            .hasFieldOrPropertyWithValue("name", "Updated Task")
            .hasFieldOrPropertyWithValue("description", "Updated description.");
    }

    @Test
    void updateFail() throws ValidationException {
        TaskService.add(new Task("12345", "Test Task", "This is a test task description."));

        Task updated = new Task("12345", "Updated Task", "Updated description.");
        updated.setName(null);

        assertThatThrownBy(() -> TaskService.update("12345", updated))
            .isInstanceOf(ValidationException.class);
    }
}
